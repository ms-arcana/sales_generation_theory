# -*- coding: utf-8 -*-
"""第6版 回帰テスト。

食品・建設 8セルで観察された落ち方が、生成前／生成後の検査で止まることを確かめる。
「買い手が一行で落とした入力を、機械が先に止められるか」だけを見る。
"""
from datetime import date
from sales_logic import (Seat, Veto, TauItem, Mi, Seller, Nu, Scope, Declared,
                         compile_deal, validate_copy)
import cells8_v6 as C

TODAY = C.TODAY
FAIL = []


def check(name, cond, got=""):
    print(f"{'ok  ' if cond else 'NG  '}{name}{'  ' + str(got) if not cond else ''}")
    if not cond:
        FAIL.append(name)


def stops(d):
    return [f.code for f in d["findings"] if f.level == "stop"]


def rejects(d):
    return [f.code for f in d["findings"] if f.level == "reject"]


def deal(i):
    c = C.CELLS[i]
    return compile_deal(c["nu"], C.SELLERS[c["seller"]], TODAY)


print("── 生成前（A7 / A8 / R7 / R12）")
d = deal(2)   # F2-P1  オーナー系に親会社はいない
check("A7 拘束者が実在しない（うちに親会社はないよ）",
      "A7_BINDER_ABSENT" in stops(d), stops(d))

d = deal(5)   # K1-P2  ゼネコン自身が元請
check("A7 拘束の向きが逆（当社が元請だ）",
      "A7_DIRECTION_REVERSED" in stops(d), stops(d))

d = deal(3)   # F2-P2  中小への時間外上限は2020年から適用済み
check("A8 適用開始が過去（六年前に越えてる）",
      "A8_ALREADY_APPLIED" in rejects(d), rejects(d))

d = deal(6)   # K2-P1  元請が複数
check("A8 拘束者が一意でない（どの元請の話だ）",
      any(j.code == "A8_BINDER_AMBIGUOUS" for j in d["needs_judgment"]),
      [j.code for j in d["needs_judgment"]])

d = deal(1)   # F1-P2  承認リードタイムの実測がない
check("R7 実数が1つ足りない（実績はあるが実測日数がない）",
      "R7_D6c_HALF" in stops(d), stops(d))

nu = C.CELLS[0]["nu"]
check("A10 落とした段の前提が入力されていれば通る",
      "R8_PRE_MISSING" not in stops(deal(0)), stops(deal(0)))

bad = Nu(A="使えば分かる", I="装置", S1="1000万〜", S2="単発", S3=False, C_move="大仕事",
         J=C.J_F2, E_judge="手段を知らない",
         tau=[C.tau_shelf()], M=[C.M0_F, C.M_NAISEI], LT_months=8,
         buyer_context=C.CTX_F2)
check("A10 前提が空なら停止", "R8_PRE_MISSING" in stops(compile_deal(bad, C.S_ROBOT, TODAY)))

ord_nu = Nu(A="使えば分かる", I="装置", S1="1000万〜", S2="単発", S3=False, C_move="大仕事",
            J=C.J_K1, E_judge="困っていない", LT_months=3,
            tau=[TauItem("A", date(2027, 4, 1), "公的暦", "未知", q="枠", q_kappa="財源",
                         scope=Scope()),
                 TauItem("C", date(2028, 6, 30), "公的暦", "未知", q="残余", q_kappa="財源",
                         scope=Scope())],
            M=[C.M0_K, C.M_NAISEI], buyer_context=C.CTX_K1, upstream=C.UP_K1)
check("R12 逆算の着手期限が終端日より後なら棄却",
      "R12_ORDER_CONFLICT" in rejects(compile_deal(ord_nu, C.S_ROBOT, TODAY)),
      rejects(compile_deal(ord_nu, C.S_ROBOT, TODAY)))

print("\n── 生成後（A5 / A6 / A9 / A11 / R10a）")
COPY = {"②": "人日で数え直します", "③": "切替こぼれ（御社の応援労務費に当たります）",
        "④": "2027-03-01。増員工数は180〜260人日", "⑤": "この条件の下では成立しません",
        "⑥": "180〜260人日のうち110人日。手元資金は初年度820万円減、回収3.1年"}
BASE = dict(s2_unit="人日", s2_from_unit="人", s3_form_mapping="切替こぼれ＝応援労務費",
            s4_declares_repetition=True, s4_period_months=6, s6_period_months=0,
            s5_is_constraint_disclosure=True, s6_ends_imperative=False,
            s6_contains_promise=False, s6_recasts_unit=True,
            s6_kappa="財源", s6_coverage_full=False, s6_coverage_disclosed=True)
KW = dict(kappa_final=["価格", "財源"], stages=["②", "③", "④", "⑤", "⑥"], n_seats=2)


def val(**over):
    return validate_copy(COPY, Declared(**{**BASE, **over}), **KW)


v = val()
check("A6 単位を保持したまま κ_n の量を併記すれば通る", v["pass"],
      [f.code for f in v["findings"] if f.level == "stop"])
check("R10a 単発は反復の再生産にしない",
      any(f.code == "R10a_NOT_PERIODIC" for f in v["findings"]))

v = val(s6_kappa="実務性")
check("A5 ⑥が κ_n で読めなければ停止",
      "A5_NOT_EXPRESSIBLE" in [f.code for f in v["findings"]])

v = validate_copy({**COPY, "⑥": "初年度820万円減、回収3.1年"}, Declared(**BASE), **KW)
check("A6 単位を落として置き換えたら停止",
      "R10b_UNIT_ABSENT" in [f.code for f in v["findings"]])

v = val(s6_coverage_full=False, s6_coverage_disclosed=False)
check("A9 一部しか消さないのに被覆率を開示しなければ停止",
      "R10c_COVERAGE_HIDDEN" in [f.code for f in v["findings"]])

v = val(s3_form_mapping="")
check("A11 新語に既存語の対応がなければ停止",
      "R11_NO_FORM_MAPPING" in [f.code for f in v["findings"]])

v = val(s6_kappa=None)
check("A5 未宣言は停止ではなく要判断へ",
      any(j.code == "A5_KAPPA_UNDECLARED" for j in v["needs_judgment"]))

v = val(s4_period_months=12, s6_period_months=12)
check("R10a 同周期で反復させるなら停止",
      "R10a_REPRODUCES_PROBLEM" in [f.code for f in v["findings"]])

print(f"\n{'すべて通過' if not FAIL else '失敗: ' + str(FAIL)}")
