# -*- coding: utf-8 -*-
"""営業資料生成モデル 第6版 ―― 決定的コア

方針
    このモジュールは **真偽が入力から一意に決まるものだけ** を扱う。
    - 返すのは記号（コード）と構造化データのみ。表示用の日本語は持たない → messages.json
    - 意味の判定（列挙否定形か／反復を問題化しているか／比例換算か）は行わない。
      needs_judgment に積んで LLM または営業へ回す。
    - 文言は一切生成しない。

境界
    決定的  ： 集合演算・表引き・日付演算・算術・文字列の完全一致
    要判断  ： 意味・程度・言い換えの可否

第6版の変更（食品・建設 8セルのアノマリー A5〜A11）
    A5  ⑥に expressible(P, κ_n)                → check_declared / EXPR_OK
    A6  R10b は「置換」だけを禁じ「併記」は禁じない → check_unit_presence と連動
    A7  δ に拘束者を持たせ、向きを検査          → Mi.binder / Nu.upstream・downstream
    A8  τ に適用対象と拘束者を持たせる          → TauItem.scope / TauItem.binders
    A9  ⑥が消す集合 ⊆ ④で数えた集合            → R10c（被覆率の宣言）
    A10 縮退で落とした段の Γ を外から与える      → Nu.gamma_pre、宣言の値域に「未定義」
    A11 ③の新語に既存語の対応を併記            → R11
    実装の穴：R10a の 0 扱い／R7 の実数2つ／R12 τ 項間の順序

依存は標準ライブラリのみ。
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Dict, List, Optional, Sequence, Set, Tuple

STAGES = ("①", "②", "③", "④", "⑤", "⑥")
Kappa = str
Dim = str


# ══════════════════════════════════════════════════════════════════ 型

@dataclass(frozen=True)
class Seat:
    name: str
    kappa: frozenset                   # κ は集合
    chi: str
    gamma: str = "単独"
    omega: str = "社内"
    reads: bool = True
    form: frozenset = frozenset()      # その座席の文書様式に既にある語（A11）


@dataclass(frozen=True)
class Veto:
    name: str


@dataclass(frozen=True)
class Scope:
    """T軸の適用対象（A8）。出典階層とは別の軸"""
    keys: Tuple[Tuple[str, str], ...] = ()   # 買い手属性との完全一致で判定
    applied_from: Optional[date] = None      # 当該区分への適用開始日


@dataclass(frozen=True)
class TauItem:
    form: str                          # A B C D Ea Eb Ec Ed
    d: Optional[date]
    src: str                           # 法令 公的暦 自然・需要 契約 売り手都合
    known: str                         # 未知 / 既知
    q: Optional[str] = None
    q_kappa: Optional[Kappa] = None
    q_recast: bool = False             # κ_n への両替経路を同枚に書いたか（真偽）
    q_source: str = "公開統計"
    q_low: Optional[float] = None
    q_high: Optional[float] = None
    confirmed: bool = True
    wait_months: Optional[int] = None
    scope: Optional[Scope] = None      # A8：空なら棄却
    binders: Tuple[str, ...] = ()      # A8：契約・第三者承認由来の日付を握る当事者


@dataclass(frozen=True)
class Mi:
    name: str
    mtype: str                         # M0 内製 既存外注 競合 取引上位者の指定
    dims: frozenset = frozenset()
    order: Tuple[Dim, ...] = ()
    binder: Optional[str] = None       # A7：D6a / D6c の拘束者


@dataclass
class Seller:
    """売り手マスタ。真偽と数だけを持つ（説明文は持たない）"""
    registrations: Set[str] = field(default_factory=set)
    registration_expiry: Optional[date] = None        # R7 D6a の実数②
    channel_total: float = 0.0
    funnel_present: bool = False
    funnel_yield: Optional[float] = None              # R7 D6b の実数②
    upstream_approvals: int = 0
    upstream_lead_days: Optional[Tuple[int, int]] = None   # R7 D6c の実数②
    named_cases: List[Dict[str, str]] = field(default_factory=list)
    liability_scope: bool = False
    price_disclosure: bool = False


@dataclass
class Nu:
    A: str; I: str; S1: str; S2: str; S3: bool; C_move: str
    J: Sequence[Seat]
    V: Sequence[Veto] = ()
    procedural: bool = False
    downward: bool = False
    E_reader: str = "困っていない"
    E_judge: str = "困っていない"
    tau: Sequence[TauItem] = ()
    M: Sequence[Mi] = ()
    LT_months: int = 6
    buyer_context: Dict[str, str] = field(default_factory=dict)
    upstream: frozenset = frozenset()          # A7：買い手の上位にいる当事者
    downstream: frozenset = frozenset()        # A7：買い手が上位に立つ相手
    gamma_pre: Dict[str, str] = field(default_factory=dict)   # A10：資料の外で成立済みの段


@dataclass
class Declared:
    """生成器（LLM）に宣言させる値。Python は推論しない。
    None は **未定義**（その段を書いていない等）であって 0 でも空文字でもない（A10）"""
    s2_unit: Optional[str] = None
    s2_from_unit: Optional[str] = None
    s3_form_mapping: Optional[str] = None        # A11：新語 ↔ κ_n 側の既存語
    s4_declares_repetition: Optional[bool] = None
    s4_period_months: Optional[int] = None
    s6_period_months: Optional[int] = None
    s5_is_constraint_disclosure: Optional[bool] = None
    s6_ends_imperative: Optional[bool] = None
    s6_contains_promise: Optional[bool] = None
    s6_recasts_unit: Optional[bool] = None
    s6_kappa: Optional[Kappa] = None             # A5：⑥に置いた量の基準
    s6_coverage_disclosed: Optional[bool] = None  # A9：被覆率を開示したか
    s6_coverage_full: Optional[bool] = None       # A9：covered(P) = Q か


@dataclass(frozen=True)
class Finding:
    code: str                          # 機械可読。表示文は messages.json
    level: str                         # stop / reject / demote / info
    ref: str = ""


@dataclass(frozen=True)
class Judgment:
    """Python が決められないもの。LLM または営業へ回す"""
    code: str
    ref: str = ""


# ══════════════════════════════════════════════════════════════════ 表

ALLOWED: Dict[str, Set[Dim]] = {
    "M0": set(),
    "内製": {"D5", "D2", "D6b"},
    "既存外注": {"D2", "D6c", "D4", "D6b"},
    "競合": {"D7a", "D7b", "D7c", "D7d", "D1", "D2", "D3", "D4", "D6a", "D6b", "D6c"},
    "取引上位者の指定": {"D6c"},
}
PRIMARY: Dict[str, Set[Dim]] = {
    "内製": {"D5"}, "既存外注": {"D2", "D6c"},
    "競合": {"D7a", "D7b", "D7c", "D7d"}, "取引上位者の指定": {"D6c"},
}
EXPR_OK: Dict[Kappa, Set[Kappa]] = {
    "実務性": {"実務性"},
    "財源": {"財源", "価格", "説明可能性"},
    "説明可能性": {"説明可能性", "財源", "価格", "政治的可視性"},
    "価格": {"価格", "財源"},
    "政治的可視性": {"政治的可視性", "説明可能性"},
}
M0_KILL = {"A": "不可逆", "B": "機会喪失", "C": "機会喪失", "D": "逓増",
           "Ea": "不可逆", "Eb": "不可逆", "Ec": "不可逆", "Ed": "―"}
KILL_ORDER = {"不可逆": 0, "機会喪失": 1, "逓増": 2, "―": 3}
R7_DIMS = {"D6a", "D6b", "D6c"}
BINDER_REQUIRED = {"D6a": True, "D6b": False, "D6c": True}   # A7：D6b の拘束者は市場＝⊥
D7_DIMS = {"D7a", "D7b", "D7c", "D7d"}
ACQUIRE = {"買い手データ": 1, "公開統計": 0, "売り手データ": 0}
START = {"困っていない": 0, "手段を知らない": 1, "比較検討中": 4, "うちも知っている": 4}
ISO_KEYS = ("所轄庁", "規模", "業態", "商圏", "系列")
BINDER_SRC = {"契約"}                    # A8：拘束者の同定が要る出典
HARM = {"delta": 100.0, "transport": 2.0}
U, U_ASK = 1.0, 0.3

# V0 = Vocab(層1) ∪ Vocab(層2)。完全一致で検出できるものだけ扱う
V0 = ["消去対象", "残余", "カテゴリC", "様相", "必然化", "問題化", "内在的否定",
      "措定", "実然", "warrant", "前提化", "承認を積", "資本として", "共著者",
      "蝶番", "縮退", "拘束の所在", "エンテュメーメ", "省略三段論法", "外延", "被覆率"]
V0_RE = [r"(?<!法)消去(?!法)", r"M_[0-9i]|Mᵢ", r"\bD[1-7][a-d]?\b", r"T-[A-E]"]


# ══════════════════════════════════════════════════════════════════ 層1

def sigma_prod(n: Nu) -> Tuple[Set[str], bool]:
    if n.S3:
        return set(STAGES), False
    small = n.S1 in ("〜10万", "10〜100万")
    if small and n.S2 in ("四半期〜月次", "週次以上"):
        return {"①", "⑥"}, True
    if small and n.S2 in ("単発", "年次以下"):
        return {"①", "④", "⑥"}, False
    return set(STAGES), False


def j_star(n: Nu) -> Seat:
    readers = [s for s in n.J if s.reads]
    return readers[-1] if readers else n.J[-1]


def kappa_n(n: Nu) -> frozenset:
    return n.J[-1].kappa if n.J else frozenset({"実務性"})


def form_n(n: Nu) -> frozenset:
    return n.J[-1].form if n.J else frozenset()


def compute_sigma(n: Nu) -> Tuple[List[str], str, bool]:
    sp, oos = sigma_prod(n)
    if sp != set(STAGES):
        return [s for s in STAGES if s in sp], "sigma_prod", oos
    S = set(STAGES[START.get(n.E_judge, 0):])
    return [s for s in STAGES if s in S], "sigma_read", oos


def check_gamma_pre(n: Nu, S: List[str]) -> List[Finding]:
    """A10：Σ から落ちた段は「資料の外で成立済み」として明示的に与える"""
    dropped = [s for s in STAGES if s not in S and STAGES.index(s) < STAGES.index(S[-1])]
    out = []
    for s in dropped:
        if not n.gamma_pre.get(s):
            out.append(Finding("R8_PRE_MISSING", "stop", s))
    return out


def blocks_on(n: Nu, S: List[str], live: List[Mi], forms: Set[str]) -> List[str]:
    dims = {d for m in live for d in m.dims}
    E = n.E_judge
    cand = [
        ("B_visualize", E == "困っていない", "①"),
        ("B_what_is_it", E in ("困っていない", "手段を知らない"), "③"),
        ("B_form_mapping", len(n.J) >= 2, "③"),                     # A11
        ("B_compare_current", E in ("比較検討中", "うちも知っている"), "⑤"),
        ("B_spec_table", n.A == "買う前に分かる", "⑤"),
        ("B_case_numbers", n.A == "使えば分かる", "⑤"),
        ("B_precedent", "D4" in dims, "⑤"),
        ("B_mechanism", n.A == "使っても分からない", "⑤"),
        ("B_certification", n.A == "使っても分からない", "⑤"),
        ("B_trial", n.A == "使えば分かる" or n.C_move == "すぐ試せる", "⑥"),
        ("B_migration", n.C_move == "大仕事", "⑥"),
        ("B_deadline", bool(forms & {"A", "B", "C", "D"}), "④"),
        ("B_why_now", bool(forms - {"D"}), "④"),
        ("B_scope_of_date", bool(forms), "④"),                      # A8
        ("B_prohibition", bool(forms & {"Ea", "Eb", "Ec"}), "④"),
        ("B_liability_matrix", "D2" in dims, "⑤"),
        ("B_authority", "D3" in dims, "⑤"),
        ("B_opportunity_cost", "D5" in dims, "⑤"),
        ("B_third_party", bool(dims & R7_DIMS), "⑤"),
        ("B_intra_category", bool(dims & D7_DIMS), "⑥"),
        ("B_kappa_quantity", True, "⑥"),                            # A5
        ("B_coverage_table", "④" in S, "⑥"),                        # A9
        ("B_draft_reason", len(n.J) >= 2, "⑥"),
        ("B_summary_sheet", len(n.J) >= 2, "⑥"),
        ("B_human_slot", len(n.J) >= 2, "⑥"),
        ("B_layer_a", n.procedural, "⑥"),
        ("B_downward", n.downward, "⑥"),
    ]
    return [b for b, phi, st in cand if phi and st in S]


# ══════════════════════════════════════════════════════════════════ 層2

def effective_LT(n: Nu) -> int:
    return n.LT_months + max([ACQUIRE.get(t.q_source, 0) for t in n.tau] + [0])


def check_applies(n: Nu, t: TauItem, today: date) -> Optional[Finding]:
    """A8：その日付が当該買い手に効くか。出典階層とは別の軸"""
    if t.scope is None:
        return Finding("A8_SCOPE_EMPTY", "reject", f"{t.form}:{t.d}")
    for k, v in t.scope.keys:
        got = n.buyer_context.get(k)
        if got is not None and got != v:
            return Finding("A8_SCOPE_MISMATCH", "reject", f"{t.form}:{t.d} {k}={v}≠{got}")
    if t.scope.applied_from is not None and t.scope.applied_from <= today:
        return Finding("A8_ALREADY_APPLIED", "reject",
                       f"{t.form}:{t.d} from={t.scope.applied_from.isoformat()}")
    return None


def check_binder(n: Nu, t: TauItem) -> Tuple[Optional[Finding], Optional[Judgment]]:
    """A8：契約・第三者承認由来の日付は、拘束者が一意でなければ立たない"""
    if t.src not in BINDER_SRC and not t.form.startswith("E"):
        return None, None
    up = [b for b in t.binders if b in n.upstream]
    if not t.binders:
        return Finding("A8_BINDER_EMPTY", "reject", f"{t.form}:{t.d}"), None
    if not up:
        return Finding("A8_BINDER_NOT_ABOVE", "reject",
                       f"{t.form}:{t.d} {','.join(t.binders)}"), None
    if len(up) > 1:
        return None, Judgment("A8_BINDER_AMBIGUOUS", f"{t.form}:{t.d} {','.join(up)}")
    return None, None


def check_tau(n: Nu, today: date) -> Tuple[List[TauItem], List[Finding], List[Judgment]]:
    ok: List[TauItem] = []
    f: List[Finding] = []
    j: List[Judgment] = []
    forms = {t.form for t in n.tau}
    kn, lt = kappa_n(n), effective_LT(n)
    for t in n.tau:
        ref = f"{t.form}:{t.d}"
        if t.src == "売り手都合":
            f.append(Finding("SRC_SELLER", "reject", ref)); continue
        if t.form == "Ed":
            f.append(Finding("R5d_PERPETUAL_BAN", "stop", ref)); continue
        if t.d is None:
            f.append(Finding("DATE_EMPTY", "reject", ref)); continue
        if t.d <= today:
            f.append(Finding("R6a_PAST", "reject", ref)); continue
        ap = check_applies(n, t, today)
        if ap:
            f.append(ap); continue
        bf, bj = check_binder(n, t)
        if bf:
            f.append(bf); continue
        if bj:
            j.append(bj)
        months = (t.d.year - today.year) * 12 + (t.d.month - today.month)
        if t.form in ("A", "C") and months - lt < 0:
            f.append(Finding("R6b_LT_SHORT", "reject", f"{ref} {months}m<{lt}m")); continue
        if t.form == "B" and t.wait_months is None:
            f.append(Finding("WAIT_UNKNOWN", "demote", ref))
        if not t.confirmed and M0_KILL[t.form] == "不可逆":
            f.append(Finding("UNCONFIRMED_PRIMARY", "stop", ref)); continue
        if t.known == "既知" and not t.q:
            f.append(Finding("KNOWN_WITHOUT_Q", "reject", ref)); continue
        if t.q:
            if t.q_kappa is None:
                j.append(Judgment("Q_KAPPA_UNSET", ref))
            elif t.q_kappa not in EXPR_OK:
                j.append(Judgment("EXPR_TABLE_MISS", f"{ref} k={t.q_kappa}"))
            elif not (EXPR_OK[t.q_kappa] & set(kn)):
                if t.q_recast:
                    f.append(Finding("A1_RECAST_DECLARED", "info", ref))
                else:
                    f.append(Finding("A1_NOT_EXPRESSIBLE", "stop",
                                     f"{ref} {t.q_kappa}->{sorted(kn)}")); continue
        if t.q_low is not None and t.q_high is not None and t.q_low <= 0:
            f.append(Finding("Q_RANGE_CROSSES_ZERO", "stop", ref)); continue
        if t.form == "D" and not (forms & {"B", "C"}):
            f.append(Finding("TD_ALONE", "reject", ref)); continue
        ok.append(t)
    f += check_tau_order(ok, lt)
    if not ok:
        f.append(Finding("R6_NO_TAU", "stop"))
    ok.sort(key=lambda t: KILL_ORDER[M0_KILL[t.form]])
    return ok, f, j


def check_tau_order(ok: List[TauItem], lt: int) -> List[Finding]:
    """R12：C の着手期限日が、同一 τ 内の A の終端日より後にあってはならない"""
    out = []
    a_dates = [t.d for t in ok if t.form == "A" and t.d]
    if not a_dates:
        return out
    a_min = min(a_dates)
    for t in ok:
        if t.form != "C" or t.d is None:
            continue
        start_y, start_m = t.d.year, t.d.month - lt
        while start_m <= 0:
            start_m += 12; start_y -= 1
        start = date(start_y, start_m, min(t.d.day, 28))
        if start > a_min:
            out.append(Finding("R12_ORDER_CONFLICT", "reject",
                               f"C着手{start.isoformat()}>A終端{a_min.isoformat()}"))
    return out


def check_delta(n: Nu) -> Tuple[List[Mi], List[Finding]]:
    live, f = [], []
    for m in n.M:
        if m.mtype == "M0":
            f.append(Finding("M0_EXCLUDED", "info", m.name)); continue
        if not m.dims:
            f.append(Finding("DELTA_UNSET", "stop", m.name)); continue
        bad = sorted(d for d in m.dims if d not in ALLOWED.get(m.mtype, set()))
        if bad:
            f.append(Finding("ALLOWED_VIOLATION", "stop", f"{m.name} {m.mtype}x{bad}")); continue
        a7 = check_binder_dim(n, m)
        if a7:
            f.append(a7); continue
        prim = m.order[0] if m.order else sorted(m.dims)[0]
        if prim not in PRIMARY.get(m.mtype, set()):
            f.append(Finding("PRIMARY_MISMATCH", "demote", f"{m.name} {prim}"))
        live.append(m)
    if not live:
        f.append(Finding("NO_ELIMINABLE_MI", "stop"))
    return live, f


def check_binder_dim(n: Nu, m: Mi) -> Optional[Finding]:
    """A7：拘束者が実在し、かつ向きが買い手より上であること"""
    need = sorted(d for d in m.dims if BINDER_REQUIRED.get(d))
    if not need:
        return None
    if not m.binder:
        return Finding("A7_BINDER_UNSET", "stop", f"{m.name} {need}")
    if m.binder in n.downstream:
        return Finding("A7_DIRECTION_REVERSED", "stop", f"{m.name} {m.binder}")
    known = set(n.upstream) | {s.name for s in n.J} | {v.name for v in n.V}
    if m.binder not in known:
        return Finding("A7_BINDER_ABSENT", "stop", f"{m.name} {m.binder}")
    if m.binder not in n.upstream:
        return Finding("A7_NOT_ABOVE", "stop", f"{m.name} {m.binder}")
    return None


def pick_two(live: List[Mi]) -> List[str]:
    order = {"既存外注": 0, "取引上位者の指定": 1, "内製": 2, "競合": 3}
    return [m.name for m in sorted(live, key=lambda m: order.get(m.mtype, 9))[:2]]


def iso_cases(n: Nu, seller: Seller) -> Tuple[List[Dict[str, str]], List[Judgment]]:
    keep, j = [], []
    missing = [k for k in ISO_KEYS if not n.buyer_context.get(k)]
    if missing and seller.named_cases:
        j.append(Judgment("ISO_CONTEXT_MISSING", ",".join(missing)))
    for c in seller.named_cases:
        if not c.get("実名"):
            continue
        if any(n.buyer_context.get(k) and c.get(k) != n.buyer_context.get(k) for k in ISO_KEYS):
            continue
        keep.append(c)
    return keep, j


def check_C_singleton(n: Nu, seller: Seller) -> Tuple[Finding, List[str]]:
    B1 = any("価格" in s.kappa for s in n.J)
    comparing = n.E_judge in ("比較検討中", "うちも知っている")
    if not B1 and not comparing:
        return Finding("A2_NOT_REQUIRED", "info"), []
    have = []
    if iso_cases(n, seller)[0]: have.append("D7a")
    if seller.registrations: have.append("D7b")
    if seller.liability_scope: have.append("D7c")
    if seller.price_disclosure: have.append("D7d")
    if not have:
        return Finding("A2_C_NOT_SINGLETON", "stop"), []
    return Finding("A2_SATISFIED", "info", ",".join(have)), have


def check_R7(live: List[Mi], seller: Seller) -> List[Finding]:
    """第6版：次元ごとに実数を **2つ** 要求する"""
    pairs = {
        "D6a": (bool(seller.registrations), seller.registration_expiry is not None),
        "D6b": (seller.channel_total > 0 and seller.funnel_present,
                seller.funnel_yield is not None),
        "D6c": (seller.upstream_approvals > 0, seller.upstream_lead_days is not None),
    }
    out = []
    for m in live:
        for d in sorted(m.dims & R7_DIMS):
            a, b = pairs[d]
            if a and b:
                out.append(Finding(f"R7_{d}_OK", "info", m.name))
            elif a and not b:
                out.append(Finding(f"R7_{d}_HALF", "stop", m.name))
            else:
                out.append(Finding(f"R7_{d}_MISSING", "stop", m.name))
    return out


def fire_rules(n: Nu, tau_ok: List[TauItem], live: List[Mi], S: List[str]) -> List[str]:
    dims = {d for m in live for d in m.dims}
    r = []
    if "D5" in dims: r.append("R1_OK" if tau_ok else "R1_VIOLATION")
    if "D2" in dims: r.append("R2")
    if "D3" in dims: r.append("R3")
    if "D4" in dims: r.append("R4")
    for t in tau_ok:
        if t.form.startswith("E"):
            r.append(f"R5{t.form[1]}")
    if dims & R7_DIMS: r.append("R7")
    if dims & D7_DIMS: r.append("A2")
    r.append("N1_ENTHYMEME_OK" if len(n.J) == 1 else "N2_WRITE_CONCLUSION")
    if any(s.gamma == "合議" for s in n.J): r.append("GAMMA_COLLEGIAL")
    if any("価格" in s.kappa for s in n.J): r.append("B1")
    if n.J and any(s.chi != n.J[0].chi for s in n.J): r.append("B2")
    if n.J and (n.J[-1].gamma == "合議" or n.J[-1].omega == "社外"): r.append("B3")
    if n.procedural: r.append("PROCEDURAL")
    if n.downward: r.append("DOWNWARD")
    r.append("A5_KAPPA_QUANTITY")
    if "③" in S and len(n.J) >= 2: r.append("R11_FORM_MAPPING")
    if "④" in S: r.append("R10c_COVERAGE")
    for v in n.V:
        r.append(f"VETO:{v.name}")
    return r


def theta_auto(kind: str) -> float:
    return 1.0 - U_ASK / (U + HARM[kind])


def segment_action(kind: str, c: float, n_cand: int) -> str:
    if n_cand > 3:
        return "STOP"
    return "AUTO" if c >= theta_auto(kind) else "OFFER_CANDIDATES"


# ══════════════════════════════════════════════════════════════════ 生成前

def compile_deal(n: Nu, seller: Seller, today: date) -> dict:
    S, by, oos = compute_sigma(n)
    if oos:
        return {"generate": False, "out_of_scope": True, "sigma": S, "sigma_by": by,
                "findings": [Finding("OUT_OF_SCOPE_LOW_INVOLVEMENT", "stop")],
                "needs_judgment": [], "llm_calls": 0}
    pre = check_gamma_pre(n, S)
    tau_ok, tf, tj = check_tau(n, today)
    live, df = check_delta(n)
    cf, d7 = check_C_singleton(n, seller)
    r7 = check_R7(live, seller)
    _, ij = iso_cases(n, seller)
    findings = pre + tf + df + [cf] + r7
    judgments = tj + ij
    stop = [x for x in findings if x.level == "stop"]
    return {
        "sigma": S, "sigma_by": by, "out_of_scope": False,
        "j_star": j_star(n).name, "kappa_n": sorted(kappa_n(n)),
        "form_n": sorted(form_n(n)),
        "tau_ok": [(t.form, t.d.isoformat(), t.src, t.known) for t in tau_ok],
        "delta": [(m.name, m.mtype, sorted(m.dims), m.binder) for m in live],
        "five_mentions": pick_two(live),
        "d7_basis": d7,
        "blocks": blocks_on(n, S, live, {t.form for t in tau_ok}),
        "rules": fire_rules(n, tau_ok, live, S),
        "findings": findings,
        "needs_judgment": judgments,
        "generate": not stop,
        "llm_calls": 0 if stop else 1 + len(S),
    }


# ══════════════════════════════════════════════════════════════════ 生成後（層3.5）

def check_v0(copy: Dict[str, str]) -> List[Finding]:
    """禁止語彙の完全一致。ここは決定的"""
    out = []
    for st, w in copy.items():
        if not w:
            continue
        for v in V0:
            if v in w:
                out.append(Finding("R9_V0", "stop", f"{st}:{v}"))
        for p in V0_RE:
            if re.search(p, w):
                out.append(Finding("R9_V0_RE", "stop", f"{st}:{p}"))
    return out


def check_unit_presence(copy: Dict[str, str], dec: Declared) -> Tuple[List[Finding], bool]:
    """②で導入した単位が⑥に出現するか。A6：出現していれば『併記』であって置換ではない"""
    if not dec.s2_unit:
        return [], True
    kept = dec.s2_unit in copy.get("⑥", "")
    return ([] if kept else [Finding("R10b_UNIT_ABSENT", "stop", dec.s2_unit)]), kept


def check_declared(dec: Declared, kn: Set[Kappa], kept_unit: bool,
                   stages: Sequence[str], n_seats: int) -> Tuple[List[Finding], List[Judgment]]:
    """宣言された値の比較のみ。意味判定はしない。None は未定義（A10）"""
    f, j = [], []
    has4, has2, has3 = "④" in stages, "②" in stages, "③" in stages

    # R10a 反復の再生産（0 は「反復しない」。比較の定義域に入れない）
    if has4:
        if dec.s4_declares_repetition is None:
            j.append(Judgment("S4_REPETITION_UNDECLARED"))
        elif dec.s4_declares_repetition:
            if dec.s4_period_months is None or dec.s6_period_months is None:
                f.append(Finding("R10a_PERIOD_UNDECLARED", "stop"))
            elif dec.s6_period_months == 0 or dec.s4_period_months == 0:
                f.append(Finding("R10a_NOT_PERIODIC", "info",
                                 f"s4={dec.s4_period_months}m s6={dec.s6_period_months}m"))
            elif dec.s6_period_months <= dec.s4_period_months:
                f.append(Finding("R10a_REPRODUCES_PROBLEM", "stop",
                                 f"s4={dec.s4_period_months}m s6={dec.s6_period_months}m"))

    # R10b 単位。A6：禁じるのは置換であって併記ではない
    if has2 and dec.s2_unit:
        if dec.s6_recasts_unit is None:
            j.append(Judgment("S6_UNIT_RECAST_UNDECLARED", dec.s2_unit))
        elif dec.s6_recasts_unit and not kept_unit:
            f.append(Finding("R10b_UNIT_REPLACED", "stop",
                             f"{dec.s2_from_unit}->{dec.s2_unit}"))
        elif dec.s6_recasts_unit and kept_unit:
            f.append(Finding("R10b_UNIT_JUXTAPOSED", "info", dec.s2_unit))

    # A5 ⑥が κ_n で読めるか
    if dec.s6_kappa is None:
        j.append(Judgment("A5_KAPPA_UNDECLARED"))
    elif dec.s6_kappa not in EXPR_OK:
        j.append(Judgment("EXPR_TABLE_MISS", f"⑥ k={dec.s6_kappa}"))
    elif not (EXPR_OK[dec.s6_kappa] & set(kn)):
        f.append(Finding("A5_NOT_EXPRESSIBLE", "stop",
                         f"{dec.s6_kappa}->{sorted(kn)}"))

    # A9 外延
    if has4:
        if dec.s6_coverage_full is None:
            j.append(Judgment("A9_COVERAGE_UNDECLARED"))
        elif not dec.s6_coverage_full:
            if dec.s6_coverage_disclosed is None:
                j.append(Judgment("A9_DISCLOSURE_UNDECLARED"))
            elif not dec.s6_coverage_disclosed:
                f.append(Finding("R10c_COVERAGE_HIDDEN", "stop"))

    # A11 名づけの移送
    if has3 and n_seats >= 2:
        if dec.s3_form_mapping is None:
            j.append(Judgment("R11_MAPPING_UNDECLARED"))
        elif not dec.s3_form_mapping.strip():
            f.append(Finding("R11_NO_FORM_MAPPING", "stop"))

    if dec.s5_is_constraint_disclosure is None:
        j.append(Judgment("S5_FORM_UNDECLARED"))
    elif dec.s5_is_constraint_disclosure is False:
        f.append(Finding("R9_S5_NOT_CONSTRAINT", "stop"))
    if dec.s6_ends_imperative is None:
        j.append(Judgment("S6_IMPERATIVE_UNDECLARED"))
    elif dec.s6_ends_imperative:
        f.append(Finding("R9_S6_IMPERATIVE", "stop"))
    if dec.s6_contains_promise is None:
        j.append(Judgment("S6_PROMISE_UNDECLARED"))
    elif dec.s6_contains_promise:
        f.append(Finding("R9_S6_PROMISE", "stop"))
    return f, j


def validate_copy(copy: Dict[str, str], dec: Declared,
                  kappa_final: Sequence[Kappa] = ("実務性",),
                  stages: Sequence[str] = STAGES, n_seats: int = 2) -> dict:
    uf, kept = check_unit_presence(copy, dec)
    f = check_v0(copy) + uf
    f2, j = check_declared(dec, set(kappa_final), kept, stages, n_seats)
    f += f2
    stop = [x for x in f if x.level == "stop"]
    return {"findings": f, "needs_judgment": j, "pass": not stop and not j}
